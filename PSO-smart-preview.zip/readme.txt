This is the PSO Smart Preview Project for Rhythmyx 6.x  

THIS VERSION REQUIRES RHYTHMYX 6.5.2 OR LATER 


To deploy the toolkit, unzip the distribution into an empty directory. 

You must have Java 1.5 and Apache Ant properly intstalled. 

The RHYTHMYX_HOME environment variable must point at your 
Rhythmyx installation.  

Type the command: 

ant -f deploy.xml 

